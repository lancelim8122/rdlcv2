﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace RIMS.Common
{
    public class Utility
    {
        internal string getProjectFilePath(string filePath)
        {
            var result = string.Empty;
            if (!string.IsNullOrWhiteSpace(filePath))
            {
                result = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                result = Path.Combine(result, filePath);
                result = Path.GetFullPath(result);
            }
            return result;
        }

        internal string getImageFilePath(string filePath)
        {
            var result = string.Empty;
            if (!string.IsNullOrWhiteSpace(filePath))
            {
                result = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                result = Path.Combine(result, filePath);
                result = "file:\\" + Path.GetFullPath(result);
            }
            return result;
        }
    }
}
