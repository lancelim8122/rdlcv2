﻿using Microsoft.Reporting.NETCore;
using RIMS.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace WMS.Common
{
    public class PDFGenerator
    {
        public byte[] SavePDF(LocalReport viewer)
        {
            var deviceInfo = @"<DeviceInfo>
                    <EmbedFonts>None</EmbedFonts>
                   </DeviceInfo>";
            byte[] Bytes = viewer.Render(format: "PDF", deviceInfo: deviceInfo);
            var fileName = viewer.DisplayName + ".pdf";
            //File.WriteAllBytes(fileName, Bytes);
            return Bytes;
        }
    }
}