﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Renci.SshNet;
using Renci.SshNet.Sftp;
using RIMS.OrderManagementWorkflow.Activities.Extensions;
using RIMS.OrderManagementWorkflow.Activities.Models;
using RIMS.OrderManagementWorkflow.Activities.Models.Callback;
using RIMS.OrderManagementWorkflow.Service;
using RIMS.OrderManagementWorkflow.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static RIMS.OrderManagementWorkflow.Constants;

namespace RIMS.OrderManagementWorkflow.Activities
{
    public class CallbackCustomActivity
    {
        private readonly IDistributedCache distributedCache;
        private readonly IConfiguration config;

        public CallbackCustomActivity(IDistributedCache distributedCache, IConfiguration config)
        {
            this.distributedCache = distributedCache;
            //this.memoryCache = memoryCache;
            this.config = config;
        }

        public ResponseBody<CallbackResponse> CallBack(string applicationId, string documentName, string signedDateTime, string hashValue, string sessionId, string requestId)
        {
            var apiResponse = new ResponseBody<CallbackResponse>();
            apiResponse.ResponseHeader = new ResponseHeader();
            apiResponse.ResponseDetails = new CallbackResponse()
            {
                DocumentName = documentName,
                ApplicationId = applicationId
            };

            try
            {
                var fileBytesList = new List<byte[]>();
                var secretKey = "";
                var host = config.GetValue<string>("SFTPConfiguration:host");
                var usernameHost = config.GetValue<string>("SFTPConfiguration:username");
                var afterSignPath = config.GetValue<string>("Paths:AfterSignPath");
                var privateKeyFilePath = config.GetValue<string>("SFTPConfiguration:PrivateKeyFilePath");
                var passPhrase = config.GetValue<string>("SFTPConfiguration:Passphrase");
                var configTxtPath = config.GetValue<string>("Paths:ConfigTxtPath");
                var zipFileName = config.GetValue<string>("Paths:ZipFileName");

                #region Retrieve PDF and .SIG file from File Server

                fileBytesList = GetFileBytesList(documentName, afterSignPath);

                #endregion

                #region Retrieve PDF and .SIG file from SFTP server

                //fileBytesList = GetFilesFromRemoteToByte(host, usernameHost, afterSignPath, documentName, privateKeyFilePath,
                //                                            passPhrase);

                #endregion

                #region Decrypt .DAT file for SecretKey

                secretKey = DecryptDATFileForSecretKey(configTxtPath, zipFileName);

                #endregion

                #region Validate Hash

                ValidateHash(fileBytesList, signedDateTime, hashValue, secretKey, sessionId, requestId, documentName);

                #endregion

                apiResponse.ResponseHeader.ResponseStatus = ResponseCode.SUCCESSMSG;
                apiResponse.ResponseHeader.ErrorCode = ResponseCode.SUCCESS;
                apiResponse.ResponseHeader.ErrorHost = null;
                apiResponse.ResponseHeader.ErrorDesc = null;

                apiResponse.ResponseDetails.StatusCode = HttpStatusCode.OK.ToString();
                apiResponse.ResponseDetails.ErrorCode = "0";
                apiResponse.ResponseDetails.ErrorMessage = null;
            }
            catch (Exception ex)
            {
                apiResponse.ResponseHeader.ResponseStatus = ResponseCode.FAILMSG;
                apiResponse.ResponseHeader.ErrorCode = ResponseCode.ErrorCodeOrderInquiry;
                apiResponse.ResponseHeader.ErrorHost = ResponseCode.RIMCode;
                apiResponse.ResponseHeader.ErrorDesc = ex.Message;

                apiResponse.ResponseDetails.StatusCode = HttpStatusCode.InternalServerError.ToString();
                apiResponse.ResponseDetails.ErrorCode = "1";
                apiResponse.ResponseDetails.ErrorMessage = ex.Message;
            }

            return apiResponse;
        }

        #region Private Methods
        private List<byte[]> GetFileBytesList(string fileName, string afterSignPath)
        {
            var result = new List<byte[]>();
            var filePathList = new List<string>();

            var pdfFilePath = string.Format("{0}\\{1}", afterSignPath, fileName);
            var sigFilesPath = string.Format("{0}\\{1}{2}", afterSignPath, fileName.Replace(".pdf",""), ".sig");
            filePathList.Add(pdfFilePath);
            filePathList.Add(sigFilesPath);

            foreach (var filePath in filePathList)
            {
                byte[] fileContent = null;
                var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                var binaryReader = new BinaryReader(fs);
                var byteLength = new FileInfo(filePath).Length;
                fileContent = binaryReader.ReadBytes((Int32)byteLength);
                fs.Close();
                fs.Dispose();
                binaryReader.Close();

                result.Add(fileContent);
            }

            return result;
        }

        private List<byte[]> GetFilesFromRemoteToByte(string host, string user, string remotePath, string fileName, string privateKeyFilePath,
                                                        string passPhrase)
        {
            var result = new List<byte[]>();

            if (!string.IsNullOrEmpty(host) || !string.IsNullOrEmpty(user) || !string.IsNullOrEmpty(remotePath))
            {
                if (!string.IsNullOrEmpty(fileName))
                {
                    var privateKey = new PrivateKeyFile(privateKeyFilePath, passPhrase);
                    var client = new SftpClient(host, user, new[] { privateKey });
                    client.KeepAliveInterval = TimeSpan.FromSeconds(60);
                    client.ConnectionInfo.Timeout = TimeSpan.FromMinutes(180);
                    client.OperationTimeout = TimeSpan.FromMinutes(180);
                    client.Connect();

                    List<SftpFile> fileList = client.ListDirectory(remotePath).ToList();

                    if (fileList != null && fileList.Count > 0)
                    {
                        foreach (var file in fileList)
                        {
                            if (file.Name == fileName || file.Name.Contains(".sig"))
                            {
                                using (var stream = new MemoryStream())
                                {
                                    client.DownloadFile(file.FullName, stream);
                                    stream.Close();

                                    result.Add(stream.ToArray());
                                }
                            }
                        }
                    }

                    client.Disconnect();
                }
                else
                    throw new Exception("Invalid Document Name.");
            }
            else
                throw new Exception("Invalid SFTP Credentials/Configuration.");

            return result;
        }

        private string DecryptDATFileForSecretKey(string configTxtPath, string zipFileName)
        {
            var result = "";

            if (!string.IsNullOrEmpty(configTxtPath))
            {
                if (!string.IsNullOrEmpty(zipFileName))
                {
                    var lines = System.IO.File.ReadAllLines(configTxtPath);

                    /* 
                     *  1. Fetch Encrypted Password and Zip Path in Config.Txt
                     */
                    var zipPath = lines[0];
                    var encryptedPassword = lines[1];

                    /* 
                     *  2. Decrypt Encrypted Password
                     */
                    // Convert Encrypted Password to Byte
                    var encryptedPasswordByte = Convert.FromBase64String(encryptedPassword);

                    var passwordByte = ProtectedData.Unprotect(encryptedPasswordByte, null, DataProtectionScope.CurrentUser);

                    var password = UnicodeEncoding.ASCII.GetString(passwordByte);

                    /* 
                     *  3. Get .DAT file from the Zip
                     */
                    var fileStream = ZipUtility.GetFileFromZip(zipFileName, zipPath, password);
                    var byteArray = fileStream.ToArray();

                    /* 
                     *  4. Decrypt .DAT file and Get Secret Key
                     */
                    var secretKeyByte = ProtectedData.Unprotect(byteArray, null, DataProtectionScope.CurrentUser);

                    result = UnicodeEncoding.ASCII.GetString(secretKeyByte);
                }
                else
                    throw new Exception("Invalid Zip File Name.");
            }
            else
                throw new Exception("Invalid Configuration Path.");

            return result;
        }

        private void ValidateHash(List<byte[]> fileBytesList, string signedDateTime, string hashValue, string secretKey, string sessionId, string requestId, string documentName)
        {
            if (fileBytesList != null && fileBytesList.Count > 0)
            {
                if (!string.IsNullOrEmpty(secretKey))
                {
                    var pdfBytes = fileBytesList[0];
                    var pdfByteValue = Encoding.Default.GetString(pdfBytes, 0, pdfBytes.Length);
                    var stringToHash = string.Format("{0}{1}{2}", pdfByteValue, signedDateTime, secretKey);
                    var generatedHash = stringToHash.SHA256_hash();

                    // If generated from file is equal to actual HashValue
                    if (generatedHash == hashValue)
                    {
                        var hashByte =  Encoding.ASCII.GetBytes(generatedHash);
                        fileBytesList.Add(hashByte);

                        // Store PDF, .SIG & Hash in DB Cache
                        var cacheKeyName = string.Format("{0}{1}{2}", sessionId, requestId, documentName);

                        var cacheService = new CacheService<byte[]>(distributedCache, config);

                        var cacheData = cacheService.CheckIfCacheList(cacheKeyName);

                        if (cacheData == null)
                        {
                            cacheService.UpdateCacheInList(cacheKeyName, fileBytesList);
                        }
                    }
                    else
                        throw new Exception("Hash doesn't match.");
                }
                else
                    throw new Exception("Invalid secret key.");
            }
            else
                throw new Exception("No files retrieve from SFTP.");
        }

        #endregion
    }
}
