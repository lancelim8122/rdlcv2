﻿using Microsoft.Reporting.NETCore;
using RIMS.BLL;
using RIMS.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RDLCDesigner.Controller.Main_Forms
{
    class SubscriptionSAMainForm
    {
        internal void formSubscriptionSAMainForm(string SPVRequestId, DataTable dtCustomer, LocalReport rv, int sectionNo, string sessionId, string entityNumber)
        {
            var utility = new Utility();
            rv.DisplayName = "ut_form_subscription_cpfsa";
            rv.ReportPath = utility.getProjectFilePath(Path.Combine("RDLC", rv.DisplayName + ".rdlc"));
            
            string path = utility.getImageFilePath(Path.Combine("Image", "Checked.jpg"));
            rv.SetParameters(new ReportParameter("CheckBoxImgUrl", path));

            #region section number assignation
            sectionNo++;
            rv.SetParameters(new ReportParameter("part_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("CRS_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("UTAcct_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("add_decl_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("subs_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("cpf_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("declaration_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("agreement_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("terms_and_cond_SecNo", sectionNo.ToString()));
            #endregion section number assignation

            var RISInstruction = string.Empty;
            var payment_type = string.Empty;

            var subReports = new SubReportService(SPVRequestId, dtCustomer, sessionId, entityNumber);
            var ds_StaticContent = subReports.getStaticContent();
            var add_decl = ds_StaticContent.AsEnumerable().Where(x => x.Field<string>("FormSection").Equals("ADD_DECL_FOR_SUBS_AND_SWT")).Select(x => x.Field<string>("Text")).FirstOrDefault();
            var IMPT_NOTE_CPFIS_SAQ = ds_StaticContent.AsEnumerable().Where(x => x.Field<string>("FormSection").Equals("IMPT_NOTE_CPFIS_SAQ")).Select(x => x.Field<string>("Text")).FirstOrDefault();

            rv.SetParameters(new ReportParameter("Add_Decl_Text", add_decl));
            rv.SetParameters(new ReportParameter("IMPT_NOTE_CPFIS_SAQ_Text", IMPT_NOTE_CPFIS_SAQ));

            #region Sub-reports
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.formSubCRS);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetUTAccountDetails);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetCPFSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetReqOrderSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetParticipantsSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetAgreementSignSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetAddDeclarationSubDataSource); 
            #endregion Sub-reports
        }
    }
}
