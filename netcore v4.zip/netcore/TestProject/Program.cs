﻿using RIMS.BLL;
using System;

namespace TestProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var result = MainReportService.GeneratePDF("ReqIdTest1", "8a3d1604-b761-49ac-9bd4-0c9fba3f3ff7");

            //var result = MainReportService.TestAppConfig();
            Console.ReadLine();
        }
    }
}
