﻿using Microsoft.Reporting.NETCore;
using RIMS.Common;
using RIMS.Datasets;
using RIMS.Datasets.WMSDatasetTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RIMS.BLL.MainForms
{
    internal class RISTerminationMainForm
    {
        internal void formRISTerminationMainForm(string SPVRequestId, DataTable dtCustomer, LocalReport rv, int sectionNo, string sessionId, string entityNumber)
        {
            var subReports = new SubReportService(SPVRequestId, dtCustomer, sessionId, entityNumber);
            var utility = new Utility();
            rv.DisplayName = "ut_form_ris_termination";
            rv.ReportPath = utility.getProjectFilePath(Path.Combine("RDLC", rv.DisplayName + ".rdlc"));

            #region section number assignation
            sectionNo++;
            rv.SetParameters(new ReportParameter("part_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("UTAcct_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("ris_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("declaration_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("agreement_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("terms_and_cond_SecNo", sectionNo.ToString()));
            #endregion section number assignation

            var payment_Type = string.Empty;
            var RISInstruction = string.Empty;

            var ds_Req_Order = subReports.ds_Req_Order_TableAdapter.GetData(SPVRequestId);
            if (ds_Req_Order != null && ds_Req_Order.Rows.Count > 0)
            {
                payment_Type = ds_Req_Order.AsEnumerable()
                    .Select(x => x.PaymentType)
                    .FirstOrDefault();

                RISInstruction = ds_Req_Order.AsEnumerable()
                    .Select(x => x.RISDividendInstruction)
                    .FirstOrDefault();
            }

            rv.SetParameters(new ReportParameter("payment_type", payment_Type));
            rv.SetParameters(new ReportParameter("RISInstruction", RISInstruction));
            rv.SetParameters(new ReportParameter("checkbox_html", utility.getImageFilePath(Path.Combine("Image", "Checked.jpg"))));

            #region Sub-reports
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetFormManageDivInsSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetParticipantsSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetUTAccountDetails);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetReqOrderSubDataSource);
            #endregion Sub-reports
        }
    }
}
