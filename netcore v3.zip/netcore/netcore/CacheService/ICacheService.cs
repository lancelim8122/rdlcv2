﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RDLCDesigner.CacheService.ICacheService
{
    public interface ICacheService<T>
    {
        List<T> CheckIfCacheList(string keyName);
        T CheckIfCache(string keyName);
        bool UpdateCache(string keyName, T dataToCache);
        bool UpdateCacheInList(string keyName, List<T> dataToCache);
    }
}
