﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RDLCDesigner.CacheService.ICacheService;
using RIMS.Datasets.WMSDatasetTableAdapters;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RIMS.CacheService
{
    public class CacheService<T> : ICacheService<T>
    {
        private readonly IDistributedCache distributedCache;
        private readonly IConfiguration config;
        private readonly DistributedCacheEntryOptions cacheEntryOption;
        SPVCacheTableAdapter sPVCacheTable = new SPVCacheTableAdapter();

        public bool _applyDefault { get; set; }

        //public CacheService(IDistributedCache distributedCache, IConfiguration config)
        //{
        //    this.distributedCache = distributedCache;
        //    this.config = config;

        //    double slidingExp = 0;
        //    double absExp = 0;

        //    double slidingExpiration = 0;
        //    double absoluteExpiration = 0;

        //    _applyDefault = false;

        //    cacheEntryOption = new DistributedCacheEntryOptions()
        //                                .SetAbsoluteExpiration(DateTime.Now.AddMinutes(5))
        //                                .SetSlidingExpiration(TimeSpan.FromMinutes(5));
        //}

        public T CheckIfCache(string keyName)
        {
            string defaultKeyName = string.Empty;

            if (!string.IsNullOrEmpty(keyName))
            {
                var keyCacheChar = keyName.ToArray();
                var prefixLst = keyCacheChar.Where(s => s == '_').ToList();

                if (prefixLst != null && prefixLst.Count > 1)
                {
                    defaultKeyName = keyName;
                }
                else
                {
                    defaultKeyName = keyName;
                }
            }
            overrideConnectionString();
            byte[] objectFromCache = sPVCacheTable.GetData(defaultKeyName).FirstOrDefault().Value;
            //byte[] objectFromCache = distributedCache.Get(defaultKeyName);

            if (objectFromCache != null && objectFromCache.Count() > 0)
            {
                string jsonToDeserialize = Encoding.UTF8.GetString(objectFromCache);
                T cachedResult = JsonConvert.DeserializeObject<T>(jsonToDeserialize);

                if (cachedResult != null)
                {
                    return cachedResult;
                }
            }

            return default(T);
        }

        public List<T> CheckIfCacheList(string keyName)
        {
            string defaultKeyName = keyName;

            byte[] objectFromCache = distributedCache.Get(defaultKeyName); //Get JSON

            if (objectFromCache != null && objectFromCache.Count() > 0)
            {
                string jsonToDeserialize = Encoding.UTF8.GetString(objectFromCache);
                List<T> cachedResultList = JsonConvert.DeserializeObject<List<T>>(jsonToDeserialize); // Json --> List<T>: Check how to utilize first

                if (cachedResultList != null)
                {
                    return cachedResultList;
                }
            }

            return null;
        }

        public dynamic CheckIfCacheLists(string keyName)
        {
            dynamic result = null;

            overrideConnectionString();

            var ds_Cache = sPVCacheTable.GetData(keyName);
            if(ds_Cache != null && ds_Cache.Rows.Count > 0)
            {
                var objectFromCache = ds_Cache.FirstOrDefault().Value;

                if (objectFromCache != null && objectFromCache.Count() > 0)
                {
                    string jsonToDeserialize = Encoding.UTF8.GetString(objectFromCache);
                    result = JsonConvert.DeserializeObject<dynamic>(jsonToDeserialize); // Json --> List<T>: Check how to utilize first
                }
            }

            return result;
        }

        public bool UpdateCache(string keyName, T dataToCache)
        {
            try
            {
                string defaultKeyName = keyName;

                byte[] objectToCache = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(dataToCache);

                distributedCache.Set(defaultKeyName, objectToCache, cacheEntryOption);
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        public bool UpdateCacheInList(string keyName, List<T> dataToCache)
        {
            try
            {
                string defaultKeyName = keyName;

                // Convert generic to JSON string
                byte[] objectToCache = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(dataToCache);

                distributedCache.Set(defaultKeyName, objectToCache, cacheEntryOption);
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        void overrideConnectionString()
        {
            sPVCacheTable.Connection.ConnectionString = ConfigurationManager.ConnectionStrings["WMSDataSetConnectionString"].ToString();
        }
    }
}
