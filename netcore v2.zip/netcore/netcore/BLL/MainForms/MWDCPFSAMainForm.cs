﻿using Microsoft.Reporting.NETCore;
using RIMS.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RIMS.BLL.MainForms
{
    internal class MWDCPFSAMainForm
    {
        internal void formMWDCPFSAMainForm(string SPVRequestId, DataTable dtCustomer, LocalReport rv, int sectionNo, string sessionId, string entityNumber)
        {
            var utility = new Utility();
            rv.DisplayName = "ut_form_mwp_id_cpfsa";
            rv.ReportPath = utility.getProjectFilePath(Path.Combine("RDLC", rv.DisplayName + ".rdlc"));

            #region section number assignation
            sectionNo++;
            rv.SetParameters(new ReportParameter("part_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("CRS_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("add_decl_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("subs_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("ris_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("Switch_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("imp_notice_switching_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("cpf_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("declaration_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("agreement_SecNo", sectionNo.ToString()));

            sectionNo++;
            rv.SetParameters(new ReportParameter("terms_and_cond_SecNo", sectionNo.ToString()));
            #endregion section number assignation

            var subReports = new SubReportService(SPVRequestId, dtCustomer, sessionId, entityNumber);
            var payment_Type = string.Empty;
            var RISInstruction = string.Empty;

            var ds_Req_Order = subReports.ds_Req_Order_TableAdapter.GetData(SPVRequestId);
            if (ds_Req_Order != null && ds_Req_Order.Rows.Count > 0)
            {
                payment_Type = ds_Req_Order.AsEnumerable()
                    .Select(x => x.PaymentType)
                    .FirstOrDefault();

                RISInstruction = ds_Req_Order.AsEnumerable()
                    .Select(x => x.RISDividendInstruction)
                    .FirstOrDefault();
            }

            var add_decl_text = "--";
            var imp_Notice_Switching_Text = "--";
            var IMPT_NOTE_CPFIS_SAQ = "--";
            var ds_StaticContent = subReports.getStaticContent();
            if (ds_StaticContent != null && ds_StaticContent.Rows.Count > 0)
            {
                add_decl_text = ds_StaticContent.AsEnumerable().
                    Where(x => x.Field<string>("FormSection").Equals("ADD_DECL_FOR_SUBS_AND_SWT")).
                    Select(x => x.Field<string>("Text")).
                    FirstOrDefault();

                imp_Notice_Switching_Text = ds_StaticContent.AsEnumerable().
                    Where(x => x.Field<string>("FormSection").Equals("IMPT_NOTICE_ON_SWITCHING")).
                    Select(x => x.Field<string>("Text")).
                    FirstOrDefault();

                IMPT_NOTE_CPFIS_SAQ = ds_StaticContent.AsEnumerable().
                    Where(x => x.Field<string>("FormSection").Equals("IMPT_NOTE_CPFIS_SAQ")).
                    Select(x => x.Field<string>("Text")).
                    FirstOrDefault();
            }

            rv.SetParameters(new ReportParameter("IMPT_NOTE_CPFIS_SAQ_Text", IMPT_NOTE_CPFIS_SAQ));
            rv.SetParameters(new ReportParameter("Imp_Notice_Switching_Text", imp_Notice_Switching_Text));
            rv.SetParameters(new ReportParameter("Add_Decl_Text", add_decl_text));
            rv.SetParameters(new ReportParameter("payment_type", payment_Type));
            rv.SetParameters(new ReportParameter("RISInstruction", RISInstruction));
            rv.SetParameters(new ReportParameter("CheckBoxImgUrl", utility.getImageFilePath(Path.Combine("Image", "Checked.jpg"))));
            rv.SetParameters(new ReportParameter("checkbox_html", utility.getImageFilePath(Path.Combine("Image", "Checked.jpg"))));

            #region Sub-reports
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetParticipantsSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.formSubCRS);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetAddDeclarationSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetReqOrderSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetReqOrderHistSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetImpNoticeSwitchingSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetCPFSubDataSource);
            #endregion Sub-reports
        }
    }
}
