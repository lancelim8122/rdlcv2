﻿using Microsoft.Reporting.NETCore;
using RDLCDesigner.Controller.Main_Forms;
using RIMS.BLL.MainForms;
using RIMS.Datasets.WMSDatasetTableAdapters;
using RIMS.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using WMS.Common;

namespace RIMS.BLL
{
    public static class MainReportService
    {
        static string uniqueId;
        static string strCreatedDate;
        static string strCreatedTime;
        static UTOrderFormStaticContentTableAdapter ds_StaticContent_TableAdapter = new UTOrderFormStaticContentTableAdapter();
        static SPVRequestCustomerCIFNoTableAdapter ds_CustomerCIFNo_TableAdapter = new SPVRequestCustomerCIFNoTableAdapter();
        static SPVSSOSessionTableAdapter ds_SPVSSOSession_TableAdapter = new SPVSSOSessionTableAdapter();
        static Req_OrderTableAdapter ds_Req_Order_TableAdapter = new Req_OrderTableAdapter();

        public static DocumentRespondModel GeneratePDF(string RequestID, string SessionID)
        {
            var result = new DocumentRespondModel();
            try
            {
                overrideTableAdapterConnectionString();

                var rv = new LocalReport();
                rv.EnableExternalImages = true;
                var sectionNo = 0;
                var currentDt = DateTime.Now;
                strCreatedDate = currentDt.ToString("dd MMM yyyy");
                strCreatedTime = currentDt.ToString("dd MMM yyyy, h:mmtt");
                var julianCalendar = new JulianCalendar().ToDateTime(currentDt.Year, currentDt.Month, currentDt.Day, currentDt.Hour, currentDt.Minute, currentDt.Second, currentDt.Millisecond);
                result.DocumentId = uniqueId = "UT" + ds_SPVSSOSession_TableAdapter.GetData(SessionID).ToString().Substring(0, 6) + julianCalendar.ToString("yyyyddd") + currentDt.ToString("HHmmss");

                var dsReqOrder = ds_Req_Order_TableAdapter.GetData(RequestID);
                if (dsReqOrder != null && dsReqOrder.Rows.Count > 0)
                {
                    var entityNumber = dsReqOrder.Rows[0]["EntityNumber"].ToString();
                    var dtCustomer = formAgreementSignSection(result, RequestID, SessionID, out SubReportService subReports, entityNumber);
                    var pmtType = dsReqOrder.Rows[0]["PaymentType"].ToString();
                    var transactionType = dsReqOrder.Rows[0]["OrderType"].ToString();
                    switch (transactionType)
                    {
                        case "SB":
                            if (pmtType != "PS_CPF_SA")
                                new SubscriptionMainForm().formSubscriptionMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            else
                                new SubscriptionSAMainForm().formSubscriptionSAMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                        case "RS":
                            if (pmtType != "PS_CPF_SA")
                                new RISNewMainForm().formRISNewMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            else
                                new RISNewSAMainForm().formRISSANewMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                        case "SW":
                            new SwitchMainForm().formSwitchMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                        case "RD":
                            new RedemptionMainForm().formRedemptionMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                        case "DI": //Dividend instruction
                            new DividendMainForm().formManageDividendInstructionMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                        case "CANCEL": // Cancellation
                            new CancellationMainForm().formCancellationMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                        case "RIS_UPD": //RIS Update
                            new RISEditMainForm().formRISEditMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                        case "RIS_TERM": //RIS Termination
                            new RISTerminationMainForm().formRISTerminationMainForm(RequestID, dtCustomer, rv, sectionNo, SessionID, entityNumber);
                            break;
                    }
                    assignCommonValue(rv, subReports);

                    result.PDFFileBytes = new PDFGenerator().SavePDF(rv);
                }
            }
            catch
            {
                throw;
            }
            return result;
        }

        static DataTable formAgreementSignSection(DocumentRespondModel result, string RequestID, string sessionId, out SubReportService subReports, string entityNumber)
        {
            var offset = ConfigurationManager.AppSettings["signBoxOffSet"].ToString();
            var width = ConfigurationManager.AppSettings["signBoxWidth"].ToString();
            var height = ConfigurationManager.AppSettings["signBoxHeight"].ToString();
            subReports = new SubReportService();

            result.SignaturePositions = new List<string>();

            var dtCustomer = new DataTable();
            dtCustomer.Columns.Add("CustomerName");
            dtCustomer.Columns.Add("SignatureParamName");

            var dsCustCIFNo = subReports.retrieveCacheData(sessionId, entityNumber);
            if (dsCustCIFNo != null && dsCustCIFNo.Cache != null &&
                dsCustCIFNo.Cache.CustomerInfo != null && dsCustCIFNo.Cache.CustomerInfo.Count > 0)
            {
                int count = 0;
                var drCust = dtCustomer.NewRow();
                var name1 = string.Empty;
                var name2 = string.Empty;
                var currDt = DateTime.Now;
                strCreatedDate = currDt.ToString("dd MMM yyyy");
                strCreatedTime = currDt.ToString("dd MMM yyyy, h:mmtt");

                while (count < dsCustCIFNo.Cache.CustomerInfo.Count)
                {
                    name1 = dsCustCIFNo.Cache.CustomerInfo[count].Name1.ToString();
                    name2 = dsCustCIFNo.Cache.CustomerInfo[count].Name2.ToString();

                    if(!string.IsNullOrWhiteSpace(dsCustCIFNo.Cache.CustomerInfo[count].Phone.ToString()) &&
                        !string.IsNullOrWhiteSpace(dsCustCIFNo.Cache.CustomerInfo[count].Email.ToString()))
                    {
                        drCust["CustomerName"] = name1 + " " + name2;
                        drCust["SignatureParamName"] = "SignParam" + count;
                        result.SignaturePositions.Add("(name=" + drCust["CustomerName"].ToString() + "|searchText=" + drCust["SignatureParamName"].ToString() + "|offset=" + offset + "|width=" + width + "|height=" + height + "|type=formfield|subtype|signature|required=true|lock_after_sign=all_editfields|archiveAction=lock_all_if_signed)");
                    }
                    else
                    {
                        result.CustomerNames.Add(name1 + " " + name2);
                    }

                    dtCustomer.Rows.Add(drCust);
                    drCust = dtCustomer.NewRow();
                    count++;
                }
                dtCustomer.AcceptChanges();
            }
            subReports = new SubReportService(RequestID, dtCustomer, sessionId, entityNumber);
            return dtCustomer;
        }

        static void assignCommonValue(LocalReport rv, SubReportService subReports)
        {
            var DeclText = "--";
            var Agreement_Text = "--";
            var FooterAddress = "--";
            var UTFormCode = "--";
            var TNC_Text = new string[6];

            var ds = ds_StaticContent_TableAdapter.GetData();
            if (ds != null && ds.Rows.Count > 0)
            {
                DeclText = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("DECLARATION"))
                    .Select(x => x.Text).FirstOrDefault() ?? "--";

                Agreement_Text = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("AGREEMENT"))
                    .Select(x => x.Text).FirstOrDefault() ?? "--";

                TNC_Text = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("TERMS_AND_COND"))
                    .Select(x => x.Text).ToArray();

                FooterAddress = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("FOOTER") && x.IndexNo.Equals("00020"))
                    .Select(x => x.Text).FirstOrDefault() ?? "--";

                UTFormCode = ds.OrderBy(x => x.IndexNo)
                    .Where(x => x.FormSection.Equals("FOOTER") && x.IndexNo.Equals("00010"))
                    .Select(x => x.Text).FirstOrDefault() ?? "--";
            }

            rv.SetParameters(new ReportParameter("Agreement_Text", Agreement_Text));
            rv.SetParameters(new ReportParameter("Decl_Text", DeclText));
            rv.SetParameters(new ReportParameter("TNC_Text", TNC_Text));
            rv.SetParameters(new ReportParameter("CreatedDate", strCreatedDate));
            rv.SetParameters(new ReportParameter("CreatedTime", strCreatedTime));
            rv.SetParameters(new ReportParameter("uniqId", uniqueId));
            rv.SetParameters(new ReportParameter("FooterAddress", FooterAddress));
            rv.SetParameters(new ReportParameter("UTFormCode", UTFormCode));

            rv.DataSources.Add(new ReportDataSource
            {
                Name = "ds_StaticContent",
                Value = ds.CopyToDataTable()
            });

            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetParticipantsSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetAgreementSignSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetDeclarationSubDataSource);
            rv.SubreportProcessing += new SubreportProcessingEventHandler(subReports.SetTNCSubDataSource);

            rv.Refresh();
        }

        static void overrideTableAdapterConnectionString()
        {
            string connString = ConfigurationManager.ConnectionStrings["WMSDataSetConnectionString"].ToString();
            ds_StaticContent_TableAdapter.Connection.ConnectionString = connString;
            ds_CustomerCIFNo_TableAdapter.Connection.ConnectionString = connString;
            ds_SPVSSOSession_TableAdapter.Connection.ConnectionString = connString;
            ds_Req_Order_TableAdapter.Connection.ConnectionString = connString;
        }

    }
}